<?php
header("Content-type:text/html;charset=utf8");
require_once("../common/Config.php");
require_once("../common/ServiceUtil.php");


$amount = "1";
$arr["merchantId"] = Config::nerchNo; //商户id
$arr["version"] = "1.0.0"; //版本号
$arr["merchantOrderNo"] = "202007111939316259"; //商户订单号
$arr["amount"] = $amount; //金额 元
$arr["submitTime"] = date("YmdHis",time());//订单提交时间
//排序
ksort($arr);
//拼接签名字符串
$signData = ServiceUtil::get_sign($arr);
//获取私钥
$privateKey = ServiceUtil::privateKeyStr(Config::privateKey);
//生成签名
$sign = ServiceUtil::sign($signData,$privateKey);
$arr["sign"] = $sign;
$reqData = json_encode($arr);
$result  = ServiceUtil::curlPost(Config::remitQuery, $reqData);
$resultArr = json_decode($result, true);;
if($resultArr['code'] == "0"){
	// 验签
	$reSign = $resultArr["sign"];
	unset($resultArr["sign"]);
	ksort($resultArr);
	//拼接签名字符串
	$signData = ServiceUtil::get_sign($resultArr);
	$publickey = ServiceUtil::publicKeyStr(Config::publicKey);
	$flag = ServiceUtil::verify($signData, $reSign, $publickey);
	if($flag){
		// 0：处理中，1：成功，2：失败"
		if($resultArr["status"] == "0"){
			echo "处理中";
		}else if($resultArr["status"] == "1"){
			echo "成功";
		}else if($resultArr["status"] == "2"){
			echo "失败";
		}

	}else{
		echo "验签失败！";
	}

}else{

  echo  $resultArr["msg"];

}
