<?php
header("Content-type:text/html;charset=utf8");
require_once("../common/Config.php");
require_once("../common/ServiceUtil.php");


$amount = "1";
$arr["merchantId"] = Config::nerchNo; //商户id
$arr["version"] = "1.0.0"; //版本号
$arr["merchantOrderNo"] = date("YmdHis",time()).rand(1000,10000); //商户订单号
$arr["amount"] = $amount; //金额 元
$arr["bankCode"] = "ICBC";//银行代码
$arr["bankcardAccountNo"] = "6222034000025435476";//银行卡号
$arr["bankcardAccountName"] = "罗平";//持卡人姓名
$arr["notifyUrl"] = "http://2023cc5dee47.ngrok.io/juming/remit/callback.php";//回调地址
//排序
ksort($arr);
//拼接签名字符串
$signData = ServiceUtil::get_sign($arr);
//获取私钥
$privateKey = ServiceUtil::privateKeyStr(Config::privateKey);
//生成签名
$sign = ServiceUtil::sign($signData,$privateKey);
$arr["sign"] = $sign;
$reqData = json_encode($arr, JSON_UNESCAPED_UNICODE);
ServiceUtil::writelog("debug","代付下单订单号：".$arr["merchantOrderNo"]);
$result  = ServiceUtil::curlPost(Config::remiturl, $reqData);
$resultArr = json_decode($result, true);
if($resultArr['code'] == "0"){
	// 验签
	$reSign = $resultArr["sign"];
	unset($resultArr["sign"]);
	ksort($resultArr);
	//拼接签名字符串
	$signData = ServiceUtil::get_sign($resultArr);
	$publickey = ServiceUtil::publicKeyStr(Config::publicKey);
	$flag = ServiceUtil::verify($signData, $reSign, $publickey);
	if($flag){
		// 0：处理中，1：成功，2：失败"
		if($resultArr["status"] == "0"){
			echo "处理中";
		}else if($resultArr["status"] == "1"){
			echo "成功";
		}else if($resultArr["status"] == "2"){
			echo "失败";
		}
	}else{
		echo "验签失败！";
	}

}else{

   echo  $resultArr["msg"];

}
