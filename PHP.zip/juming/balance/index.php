<?php
header("Content-type:text/html;charset=utf8");
require_once("../common/Config.php");
require_once("../common/ServiceUtil.php");


$amount = "10";
$arr["merchantId"] = Config::nerchNo; //商户id
$arr["version"] = "1.0.0"; //版本号
$arr["requestTime"] = date("YmdHis",time()); //商户订单号
//排序
ksort($arr);
//拼接签名字符串
$signData = ServiceUtil::get_sign($arr);
//获取私钥
$privateKey = ServiceUtil::privateKeyStr(Config::privateKey);
//生成签名
$sign = ServiceUtil::sign($signData,$privateKey);
$arr["sign"] = $sign;
$reqData = json_encode($arr);
$result  = ServiceUtil::curlPost(Config::balanceUrl, $reqData);
$resultArr = json_decode($result, true);
if($resultArr['code'] == "0"){
	// 验签
	$reSign = $resultArr["sign"];
	unset($resultArr["sign"]);
	ksort($resultArr);
	//拼接签名字符串
	$signData = ServiceUtil::get_sign($resultArr);
	$publickey = ServiceUtil::publicKeyStr(Config::publicKey);
	$flag = ServiceUtil::verify($signData, $reSign, $publickey);
	if($flag){
		echo "可用余额:".$resultArr["availableAmount"]."元<br/>";
		echo "冻结金额:".$resultArr["frozenAmount"]."元<br/>";
		echo "未结算金额:".$resultArr["unsettledAmount"]."元<br/>";
	}else{
		echo "验签失败！";
	}

}else{

  echo "下单失败";

}