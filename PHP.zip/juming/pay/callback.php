<?php
header("Content-type:text/html;charset=utf8");
require_once("../common/Config.php");
require_once("../common/ServiceUtil.php");

//接收异步通知数据
$post = file_get_contents("php://input");
ServiceUtil::writelog("debug","支付通知数据：".json_encode($post));
$resultArr = json_decode($post, true);
$reSign = $resultArr["sign"];
unset($resultArr["sign"]);
ksort($resultArr);
$publickey = ServiceUtil::publicKeyStr(Config::publicKey);
$signData = ServiceUtil::get_sign($resultArr);
//验签
$flag = ServiceUtil::verify($signData, $reSign, $publickey);
if($flag){
	//判断订单状态
	if($resultArr["status"] == "1"){
		ServiceUtil::writelog("debug","支付订单成功：".$resultArr["merchantOrderNo"]);
	}
	if($resultArr["status"] == "2"){
		ServiceUtil::writelog("debug","支付订单失败：".$resultArr["merchantOrderNo"]);
	}
	ServiceUtil::writelog("debug","支付回调响应：success");
	echo "success";
}else{
	ServiceUtil::writelog("debug","支付订单验签失败：".$resultArr["merchantOrderNo"]);
	echo "fail";

}