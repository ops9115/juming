import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.jm.demo.service.DemoService;
import org.junit.Test;

import java.util.Date;

public class DemoTest {
    private DemoService demoService = new DemoService();

    @Test
    public void test() {
        JSONObject payOrderDate = demoService.submitPayOrder("20190923162715", "ALIPAY_QR_CODE", "100", "100", "http://www.baidu.com");
        JSONObject viewPayDate = demoService.viewPayOrder("20190923162701", new Date());
        JSONObject remitOrderData = demoService.submitRemitOrder("20190921202001", "ICBC", "100", "123456789123456789", "电风扇", "http://www.baidu.com");
        JSONObject viewRemitData = demoService.viewRemitOrder("20190921202001", new Date());
        JSONObject balance = demoService.viewBalance();

        System.out.println("支付下单返回 "+ JSON.toJSONString(payOrderDate));
        System.out.println("支付查询返回 "+ JSON.toJSONString(viewPayDate));
        System.out.println("代付下单返回 "+ JSON.toJSONString(remitOrderData));
        System.out.println("代付查询返回 "+ JSON.toJSONString(viewRemitData));
        System.out.println("余额查询返回 "+ JSON.toJSONString(balance));
    }
}
