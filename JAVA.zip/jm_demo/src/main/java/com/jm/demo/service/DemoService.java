package com.jm.demo.service;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.alibaba.fastjson.TypeReference;
import com.jm.demo.Const.Const;
import com.jm.demo.utils.DateUtils;
import com.jm.demo.utils.HttpUtils;
import com.jm.demo.utils.RSAUtils;
import org.apache.commons.lang3.StringUtils;

import java.util.Date;
import java.util.Map;
import java.util.TreeMap;
import java.util.stream.Collectors;

public class DemoService {

    /**
     * 创建订单
     * @param merchantOrderNo 商户订单号
     * @param model 订单模式
     * @param amount 金额 单位元
     * @param memberNo 商户会员号 选填
     * @param notifyUrl 回调地址
     * @return
     */
    public JSONObject submitPayOrder(String merchantOrderNo, String model, String amount, String memberNo, String notifyUrl) {
        JSONObject jsonObject = new JSONObject();

        try {
            Map<String, String> params = new TreeMap<>();
            params.put("merchantOrderNo", merchantOrderNo);
            params.put("amount", amount);
            params.put("model", model);
            params.put("memberNo", memberNo);
            params.put("notifyUrl", notifyUrl);
            jsonObject.put("paramsData", JSON.toJSONString(params));
            params = convert(params);
            jsonObject.put("params", JSON.toJSONString(params));

            String result = HttpUtils.post(Const.SUBMITPAYORDERURL, JSON.toJSONString(params));
            jsonObject.put("result", result);
            JSONObject data = JSONObject.parseObject(result);
            if (data.getInteger("code") == 0 && RSAUtils.verify(data)) {
                jsonObject.put("resultData", data.toJSONString());
                System.out.println(HttpUtils.post(data.get("url").toString(), ""));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return jsonObject;
    }

    /**
     * 查询支付订单
     * @param merchantOrderNo 商户订单号
     * @param submitDate 提交时间  yyyyMMddHHmmss 误差在一小时之内
     * @return
     */
    public JSONObject viewPayOrder(String merchantOrderNo, Date submitDate) {
        JSONObject jsonObject = new JSONObject();

        try {
            Map<String, String> params = new TreeMap<>();
            params.put("merchantOrderNo", merchantOrderNo);
            params.put("submitTime", DateUtils.format(submitDate, "yyyyMMddHHmmss"));
            jsonObject.put("paramsData", JSON.toJSONString(params));
            params = convert(params);
            jsonObject.put("params", JSON.toJSONString(params));

            String result = HttpUtils.post(Const.EXAMINEPAYURL, JSON.toJSONString(params));
            jsonObject.put("result", result);
            JSONObject data = JSONObject.parseObject(result);
            if (data.getInteger("code") == 0 && RSAUtils.verify(data)) {
                jsonObject.put("resultData", data.toJSONString());
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return jsonObject;
    }

    /**
     *  提现
     * @param merchantOrderNo 商户订单号
     * @param bankCode 银行编码
     * @param amount 金额
     * @param bankcardAccountNo  银行卡账号
     * @param bankcardAccountName 持卡人姓名
     * @param notifyUrl 通知地址
     * @return
     */
    public JSONObject submitRemitOrder(String merchantOrderNo, String bankCode, String amount, String bankcardAccountNo, String bankcardAccountName, String notifyUrl) {
        JSONObject jsonObject = new JSONObject();

        try {
            Map<String, String> params = new TreeMap<>();
            params.put("merchantOrderNo", merchantOrderNo);
            params.put("amount", amount);
            params.put("bankCode", bankCode);
            params.put("bankcardAccountNo", bankcardAccountNo);
            params.put("bankcardAccountName", bankcardAccountName);
            params.put("notifyUrl", notifyUrl);
            jsonObject.put("paramsData", JSON.toJSONString(params));
            params = convert(params);
            jsonObject.put("params", JSON.toJSONString(params));

            String result = HttpUtils.post(Const.SUBMITREMITORDERURL, JSON.toJSONString(params));
            jsonObject.put("result", result);
            JSONObject data = JSONObject.parseObject(result);
            if (data.getInteger("code") == 0 && RSAUtils.verify(data)) {
                jsonObject.put("resultData", data.toJSONString());
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return jsonObject;
    }

    /**
     * 余额查询
     * @return
     */
    public JSONObject viewBalance() {
        JSONObject jsonObject = new JSONObject();

        try {
            Map<String, String> params = new TreeMap<>();
            params.put("requestTime", DateUtils.format(new Date(), "yyyyMMddHHmmss"));
            jsonObject.put("paramsData", JSON.toJSONString(params));
            params = convert(params);
            jsonObject.put("params", JSON.toJSONString(params));

            String result = HttpUtils.post(Const.EXAMINEBALANCEURL, JSON.toJSONString(params));
            jsonObject.put("result", result);
            JSONObject data = JSONObject.parseObject(result);
            if (data.getInteger("code") == 0 &&  RSAUtils.verify(data)) {
                jsonObject.put("resultData", data.toJSONString());
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return jsonObject;
    }

    /**
     *  提现查询
     * @param merchantOrderNo 商户订单号
     * @param submitDate 提交时间 一小时以内 yyyyMMddHHmmss
     * @return
     */
    public JSONObject viewRemitOrder(String merchantOrderNo, Date submitDate) {
        JSONObject jsonObject = new JSONObject();

        try {
            Map<String, String> params = new TreeMap<>();
            params.put("merchantOrderNo", merchantOrderNo);
            params.put("submitTime", DateUtils.format(submitDate, "yyyyMMddHHmmss"));
            jsonObject.put("paramsData", JSON.toJSONString(params));
            params = convert(params);
            jsonObject.put("params", JSON.toJSONString(params));

            String result = HttpUtils.post(Const.EXAMINEREMITURL, JSON.toJSONString(params));
            jsonObject.put("result", result);
            JSONObject data = JSONObject.parseObject(result);
            if (data.getInteger("code") == 0 &&  RSAUtils.verify(data)) {
                jsonObject.put("resultData", data.toJSONString());
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return jsonObject;
    }

    /**
     * 支付回调
     * @param callBackData 具体请参考文档回调参数描述
     * @return
     */
    public String payOrderCallback(String callBackData) {
        try {
            //对回调数据进行sign验证
            if (RSAUtils.verify(JSONObject.parseObject(callBackData))){
                return  "success";
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return "fail";
    }


    /**
     * 参数转换
     *
     * @param data 参数
     * @return 转换结果
     */
    private Map<String, String> convert(Map<String, String> data) throws Exception {
        data.put("merchantId", Const.MERID);
        data.put("version", "1.0.0");
        data.put("sign", sign(data, Const.PRIVATEK));
        return data;
    }

    private String sign(Map<String, String> data, String privateKey) throws Exception {
        String signData = data.entrySet().stream().filter(e -> StringUtils.isNotEmpty(e.getValue())).map(e -> e.getKey().concat("=").concat(e.getValue())).collect(Collectors.joining("&"));
        System.out.println(signData);
        return RSAUtils.sign(signData, privateKey);
    }

    /**
     * 代付反查
     * @param remitOrderReverseData 具体请参考文档代付反查参数描述
     * @return
     */
    public JSONObject remitOrderReverseQuery(String remitOrderReverseData) {
        JSONObject jsonObject = null;
        try {
            Map<String, String> map = JSON.parseObject(remitOrderReverseData, new TypeReference<TreeMap<String, String>>(){});
            String sign = map.remove("sign");
            String signData = map.entrySet().stream().filter(e -> StringUtils.isNotEmpty(e.getValue())).map(e -> e.getKey().concat("=").concat(e.getValue())).collect(Collectors.joining("&"));
            // merchantOrderNo merchantOrderAmount 为模拟逻辑
            String orderId = map.get("merchantOrderNo");
            String amount = map.get("amount");
            String merchantOrderNo = orderId;
            String merchantOrderAmount = amount;
            Map<String, String > params = new TreeMap<>();
            //验签
            if (RSAUtils.verify(JSON.parseObject(signData)) ||
                    !StringUtils.equals(merchantOrderAmount,amount) ||
                    !StringUtils.equals(merchantOrderNo,orderId)){
                params.put("code", "1");
                params.put("message", "操作失败");
            }else{
                //订单验证成功
                params.put("code", "0");
                params.put("message", "操作成功");
                params.put("merchantOrderNo", orderId);
            }
            params.put("sign",sign(params, Const.PRIVATEK));
            jsonObject = new JSONObject(new TreeMap<String,Object>(params));
        } catch (Exception e) {
            e.printStackTrace();
        }
        return jsonObject;
    }
}
