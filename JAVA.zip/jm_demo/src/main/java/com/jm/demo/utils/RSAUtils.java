package com.jm.demo.utils;

import com.alibaba.fastjson.JSONObject;
import com.jm.demo.Const.Const;
import org.apache.commons.lang3.StringUtils;

import java.nio.charset.StandardCharsets;
import java.security.*;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.X509EncodedKeySpec;
import java.util.Base64;
import java.util.Map;
import java.util.TreeMap;
import java.util.stream.Collectors;

/**
 * 加密工具类
 */
public class RSAUtils {

    /**
     * RSA公钥转换
     * @param publicKeyStr 公钥字符串
     * @return 公钥
     * @throws
     */
    public static PublicKey parsePublicKey(String publicKeyStr) throws InvalidKeySpecException {
        PublicKey publicKey = null;
        try {
            KeyFactory keyFactory = KeyFactory.getInstance(Const.ALGORITHM);
            byte[] encodedKey = Base64.getDecoder().decode(publicKeyStr.getBytes(StandardCharsets.UTF_8));
            publicKey = keyFactory.generatePublic(new X509EncodedKeySpec(encodedKey));
        } catch (NoSuchAlgorithmException e) {
        }
        return publicKey;
    }

    /**
     * RSA私钥转换
     *
     * @param privateKeyStr 私钥字符串
     * @return 私钥
     * @throws
     */
    public static PrivateKey parsePrivateKey(String privateKeyStr) throws InvalidKeySpecException {
        PrivateKey privateKey = null;
        try {
            KeyFactory keyFactory = KeyFactory.getInstance(Const.ALGORITHM);
            byte[] encodedKey =  Base64.getDecoder().decode(privateKeyStr.getBytes(StandardCharsets.UTF_8));
            privateKey = keyFactory.generatePrivate(new PKCS8EncodedKeySpec(encodedKey));
        } catch (NoSuchAlgorithmException e) {
        }
        return privateKey;
    }

    /**
     * 签名
     * @param data          待签名数据
     * @param privateKey    私钥
     * @return
     */
    public static String sign(String data, String privateKey) throws Exception {
        Signature signature = Signature.getInstance("SHA1withRSA");
        signature.initSign(parsePrivateKey(privateKey));
        signature.update(data.getBytes("UTF-8"));
        return new String(org.apache.commons.codec.binary.Base64.encodeBase64(signature.sign()));
    }

    /**
     * 验签
     * @param data
     * @return
     * @throws Exception
     */
    public static boolean verify(JSONObject data) throws Exception {
        Map<String,String> map = JSONObject.toJavaObject(data, Map.class);
        String sign = data.remove("sign").toString();
        String signData =  new TreeMap<>(map).entrySet().stream().filter(e -> StringUtils.isNotEmpty(e.getValue())).map(e -> e.getKey().concat("=").concat(e.getValue())).collect(Collectors.joining("&"));
        Signature signature = Signature.getInstance("SHA1withRSA");
        signature.initVerify(parsePublicKey(Const.PUBLICK));
        signature.update(signData.getBytes("UTF-8"));
        return signature.verify(org.apache.commons.codec.binary.Base64.decodeBase64(sign.getBytes("UTF-8")));
    }

}
